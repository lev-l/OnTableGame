﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class AddDopTurnsToArmy : MonoBehaviour
{
    public int DopTurns;

    private void OnTriggerEnter2D(Collider2D collision)
    {
        if (collision.gameObject.GetComponent<Army>())
        {
            collision.gameObject.GetComponent<Army>().AddTurns(DopTurns);
        }
        if (collision.gameObject.GetComponent<Caravan>())
        {
            collision.gameObject.GetComponent<Caravan>().AddTurns(DopTurns);
        }
    }
}