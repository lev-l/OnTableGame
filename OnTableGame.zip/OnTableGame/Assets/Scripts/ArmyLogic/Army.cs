﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public enum States
{
    Default,
    Choosed,
    Moving,
    Stoped
}

public enum ArmyTypes
{
    Arrow,
    Spear,
    Sword,
    Horse
}

public abstract class State
{
    public abstract States MousDown();
    public abstract States Up();
    public abstract void NewTurn();
}

public class DefaultState : State
{
    public override States MousDown()
    {
        return States.Choosed;
    }

    public override void NewTurn()
    {
    }

    public override States Up()
    {
        return States.Default;
    }
}

public class ChoosedState : State
{
    private ArmyStats _stats;

    public ChoosedState(ArmyStats stats)
    {
        _stats = stats;
    }

    private States MoveIf(KeyCode key, Vector3 newTarget)
    {
        newTarget.z = -1;
        if (Input.GetKeyDown(key))
        {
            _stats.Target = newTarget;
            return States.Moving;
        }
        return States.Choosed;
    }

    public override States MousDown()
    {
        return States.Default;
    }

    public override void NewTurn()
    {
    }

    public override States Up()
    {
        if (_stats.Master == _stats.Turns.Turn && _stats.CanMove > 0)
        {
            States returnedState = MoveIf(KeyCode.A, Vector3.left + _stats.Self.position);
            if (returnedState != States.Choosed)
            {
                return returnedState;
            }

            returnedState = MoveIf(KeyCode.W, Vector3.up + _stats.Self.position);
            if (returnedState != States.Choosed)
            {
                return returnedState;
            }

            returnedState = MoveIf(KeyCode.D, Vector3.right + _stats.Self.position);
            if (returnedState != States.Choosed)
            {
                return returnedState;
            }

            returnedState = MoveIf(KeyCode.S, Vector3.down + _stats.Self.position);
            if (returnedState != States.Choosed)
            {
                return returnedState;
            }
        }
        return States.Choosed;
    }
}

public class MovingState : State
{
    private ArmyStats _stats;

    public MovingState(ArmyStats stats)
    {
        _stats = stats;
    }

    public override States MousDown()
    {
        return States.Moving;
    }

    public override void NewTurn()
    {
    }

    public override States Up()
    {
        if (_stats.CanMove > 0)
        {
            _stats.Self.position = Vector3.MoveTowards(_stats.Self.position, _stats.Target, 1 * Time.deltaTime);
        }
        if (new Vector2(_stats.Self.position.x, _stats.Self.position.y) 
            == new Vector2(_stats.Target.x, _stats.Target.y))
        {
            _stats.CanMove -= 1;
            return States.Default;
        }
        else
        {
            return States.Moving;
        }
    }
}

public class StopedState : State
{
    public ArmyStats _stats;

    public StopedState(ArmyStats stats)
    {
        _stats = stats;
    }

    public override States MousDown()
    {
        return States.Stoped;
    }

    public override void NewTurn()
    {
        _stats.DopTurns--;
    }

    public override States Up()
    {
        if (_stats.DopTurns == 0)
        {
            return States.Moving;
        }
        return States.Stoped;
    }
}

public class ArmyStats
{
    public Transform Self;
    public int Master;
    public int DopTurns = 0;
    public TurnSystem Turns;
    public int CanMove;

    private Vector3 _target;
    private Vector2 _oldTarget;

    public Vector3 Target
    {
        get
        {
            return _target;
        }
        set
        {
            WillTargetChange();
            _target = value;
        }
    }

    public ArmyStats(Transform self, Vector3 target, int master, int dopTurns, TurnSystem turns)
    {
        Self = self;
        _target = target;
        Master = master;
        DopTurns = dopTurns;
        Turns = turns;
        CanMove = 1;
    }

    public void SetOldTarget()
    {
        Target = _oldTarget;
    }

    public void WillTargetChange()
    {
        _oldTarget = Target;
    }
}

public class Army : MonoBehaviour
{
    public Color[] PlayersColors;
    public ArmyStats Stats;

    private SpriteRenderer _renderer;
    private TurnSystem _turns;
    private State _state;
    private Dictionary<States, State> _states;

    private void Start()
    {
        _renderer = GetComponent<SpriteRenderer>();
        if (Stats == null)
        {
            Stats = new ArmyStats(GetComponent<Transform>(),
                                    GetComponent<Transform>().position, -1, 0, _turns);
        }
        _states = new Dictionary<States, State>();
        _states.Add(States.Default, new DefaultState());
        _states.Add(States.Choosed, new ChoosedState(Stats));
        _states.Add(States.Moving, new MovingState(Stats));
        _states.Add(States.Stoped, new StopedState(Stats));

        _state = _states[States.Default];
        Stats.CanMove = GetComponent<ArmyType>().CanMoveNum;
    }

    public void SetMaster(int master)
    {
        _renderer = GetComponent<SpriteRenderer>();
        _turns = GameObject.FindGameObjectWithTag("MainCamera").GetComponent<TurnSystem>();
        Stats = new ArmyStats(GetComponent<Transform>(),
                                GetComponent<Transform>().position, -1, 0, _turns);
        _renderer.color = PlayersColors[master - 1];
        Stats.Master = master;
    }

    public int GetMaster()
    {
        return Stats.Master;
    }

    private void OnMouseDown()
    {
        States newState = _state.MousDown();
        _state = _states[newState];
    }

    public void AddTurns(int amount)
    {
        Stats.DopTurns += amount;
        _state = _states[States.Stoped];
    }

    private void Update()
    {
        States newState = _state.Up();
        _state = _states[newState];
    }

    public void TurnChanged()
    {
        if (_turns.Turn == Stats.Master)
        {
            _state.NewTurn();
        }
        
        Stats.CanMove = GetComponent<ArmyType>().CanMoveNum;
    }
}