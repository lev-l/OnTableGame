﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ArmyType : MonoBehaviour
{
    public Sprite ArrowSkin, SpearSkin, SwordSkin, HorseSkin;
    public ArmyTypes Type { get; private set; }
    public int CanMoveNum = 1;
    private SpriteRenderer _renderer;

    private void Awake()
    {
        Type = ArmyTypes.Arrow;
        _renderer = GetComponent<SpriteRenderer>();
    }

    public void SetNewType(ArmyTypes type)
    {
        Type = type;
        switch (type)
        {
            case ArmyTypes.Arrow:
                _renderer.sprite = ArrowSkin;
                break;
            case ArmyTypes.Spear:
                _renderer.sprite = SpearSkin;
                break;
            case ArmyTypes.Sword:
                _renderer.sprite = SwordSkin;
                break;
            case ArmyTypes.Horse:
                _renderer.sprite = HorseSkin;
                CanMoveNum = 2;
                break;
        }
    }
}
