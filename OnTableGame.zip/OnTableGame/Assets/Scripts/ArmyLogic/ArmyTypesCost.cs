﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ArmyTypesCost : MonoBehaviour
{
    public Dictionary<ArmyTypes, Resurses> TypesCost;

    private void Start()
    {
        TypesCost = new Dictionary<ArmyTypes, Resurses>();
        TypesCost.Add(ArmyTypes.Arrow, new Resurses(2, 1, 0));
        TypesCost.Add(ArmyTypes.Spear, new Resurses(2, 2, 0));
        TypesCost.Add(ArmyTypes.Sword, new Resurses(2, 1, 2));
        TypesCost.Add(ArmyTypes.Horse, new Resurses(3, 3, 3));
    }
}
