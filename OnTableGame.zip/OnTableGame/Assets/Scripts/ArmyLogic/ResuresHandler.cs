﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class ResuresHandler : MonoBehaviour
{
    public GameObject CaravanResurses;
    public Resurses Resurses = new Resurses(0, 0, 0);
    public Transform[] Lands;
    private TurnSystem _turns;
    private ArmyStats _stats;
    private Text _goldText;
    private Text _goodText;
    private Text _ironText;

    private void Awake()
    {
        GameObject camera = GameObject.FindGameObjectWithTag("MainCamera");
        _turns = camera.GetComponent<TurnSystem>();
        _stats = new ArmyStats(GetComponent<Transform>(), GetComponent<Transform>().position,
                                _turns.Turn, 0, _turns);

        CaravanResurses = Instantiate(CaravanResurses, _stats.Self);
        Lands = GameObject.FindGameObjectWithTag("Lands").GetComponentsInChildren<Transform>();

        Text[] texts = CaravanResurses.GetComponentInChildren<Transform>().GetComponentsInChildren<Text>();
        foreach (Text text in texts)
        {
            switch (text.name)
            {
                case "Gold":
                    _goldText = text;
                    break;
                case "Wood":
                    _goodText = text;
                    break;
                case "Iron":
                    _ironText = text;
                    break;
            }
        }
        
        Button[] buttons = CaravanResurses.GetComponentsInChildren<Button>();
        buttons[0].onClick.AddListener(delegate { AddResurse("gold"); });
        buttons[1].onClick.AddListener(delegate { AddResurse("wood"); });
        buttons[2].onClick.AddListener(delegate { AddResurse("iron"); });

        buttons[3].onClick.AddListener(delegate { LoseResurses("gold"); });
        buttons[4].onClick.AddListener(delegate { LoseResurses("wood"); });
        buttons[5].onClick.AddListener(delegate { LoseResurses("iron"); });
    }

    public void AddResurse(string name)
    {
        foreach (Transform land in Lands)
        {
            if (land)
            {
                Vector3 position = land.position + new Vector3(0, 0, -1);
                if (GetComponent<BoxCollider2D>().bounds.Contains(position))
                {
                    if (land.name.Contains("Cell"))
                    {
                        Resurses resurses = land.GetComponent<Cell>().Resurses;
                        switch (name)
                        {
                            case "gold":
                                if (resurses.CheckGold(1))
                                {
                                    resurses.SetGold(-1);
                                    Resurses.SetGold(1);
                                }
                                break;
                            case "wood":
                                if (resurses.CheckWood(1))
                                {
                                    resurses.SetWood(-1);
                                    Resurses.SetWood(1);
                                }
                                break;
                            case "iron":
                                if (resurses.CheckIron(1))
                                {
                                    resurses.SetIron(-1);
                                    Resurses.SetIron(1);
                                }
                                break;
                        }
                    }
                }
            }
        }
    }

    public void LoseResurses(string name)
    {
        foreach (Transform land in Lands)
        {
            if (land && GetComponent<Caravan>().GetMaster() == _turns.Turn)
            {
                Vector3 position = land.position + new Vector3(0, 0, -1);
                if (GetComponent<BoxCollider2D>().bounds.Contains(position))
                {
                    if (land.name.Contains("Cell"))
                    {
                        Resurses resurses = land.GetComponent<Cell>().Resurses;
                        switch (name)
                        {
                            case "gold":
                                if (Resurses.CheckGold(1))
                                {
                                    Resurses.SetGold(-1);
                                    resurses.SetGold(1);
                                }
                                break;
                            case "wood":
                                if (Resurses.CheckWood(1))
                                {
                                    Resurses.SetWood(-1);
                                    resurses.SetWood(1);
                                }
                                break;
                            case "iron":
                                if (Resurses.CheckIron(1))
                                {
                                    Resurses.SetIron(-1);
                                    resurses.SetIron(1);
                                }
                                break;
                        }
                    }
                }
            }
        }
    }

    private void Update()
    {

        int[] items = Resurses.GetAll();

        _goldText.text = "Gold: " + items[2].ToString();
        _goodText.text = "Wood: " + items[0].ToString();
        _ironText.text = "Iron: " + items[1].ToString();
    }
}
