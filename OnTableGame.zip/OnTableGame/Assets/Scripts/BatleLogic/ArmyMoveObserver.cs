﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

interface ArmyMoveObserver
{
    void ArmyEnter(string cellName, Army army);

    void ArmyExit(string cellName, Army army);

    void TurnChanged(string cellName);
}
