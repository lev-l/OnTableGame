﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Batle : MonoBehaviour
{
    public Army[] SimulateButle(Army[] armies1, Army[] armies2, Cell cell)
    {
        int strongOf1 = 0;
        foreach (Army army in armies1)
        {
            if (army != null)
            {
                strongOf1 += Random.Range(1, 7);
            }
        }

        int strongOf2 = 0;
        foreach (Army army in armies2)
        {
            if (army != null)
            {
                strongOf2 += Random.Range(1, 7);
            }
        }

        List<ArmyTypes> armies1Types = new List<ArmyTypes>();
        foreach (Army army1 in armies1)
        {
            armies1Types.Add(army1.GetComponent<ArmyType>().Type);
        }

        List<ArmyTypes> armies2Types = new List<ArmyTypes>();
        foreach (Army army2 in armies2)
        {
            armies2Types.Add(army2.GetComponent<ArmyType>().Type);
        }
        

        if (armies1Types.Contains(ArmyTypes.Arrow) && armies2Types.Contains(ArmyTypes.Sword))
        {
            strongOf1++;
        }
        if (armies2Types.Contains(ArmyTypes.Arrow) && armies1Types.Contains(ArmyTypes.Sword))
        {
            strongOf2++;
        }
        
        if (armies1Types.Contains(ArmyTypes.Sword) && armies2Types.Contains(ArmyTypes.Spear))
        {
            strongOf1++;
        }
        if (armies2Types.Contains(ArmyTypes.Sword) && armies1Types.Contains(ArmyTypes.Spear))
        {
            strongOf2++;
        }

        if (armies1Types.Contains(ArmyTypes.Spear) && armies2Types.Contains(ArmyTypes.Horse))
        {
            strongOf1++;
        }
        if (armies2Types.Contains(ArmyTypes.Spear) && armies1Types.Contains(ArmyTypes.Horse))
        {
            strongOf2++;
        }

        if (armies1Types.Contains(ArmyTypes.Horse) && armies2Types.Contains(ArmyTypes.Arrow))
        {
            strongOf1++;
        }
        if (armies2Types.Contains(ArmyTypes.Horse) && armies1Types.Contains(ArmyTypes.Arrow))
        {
            strongOf2++;
        }


        if (cell.GetMaster() == 1)
        {
            strongOf1 += 1;
        }
        else if(cell.GetMaster() == 2)
        {
            strongOf2 += 1;
        }
        else
        {
            //no bonus
        }

        if (strongOf1 > strongOf2)
        {
            DestroyArmy(armies2);
            return armies2;
        }
        else if (strongOf2 > strongOf1)
        {
            DestroyArmy(armies1);
            return armies1;
        }
        return null;
    }

    private void DestroyArmy(Army[] armies)
    {
        foreach(Army army in armies)
        {
            if (army != null)
            {
                Destroy(army.gameObject);
            }
        }
    }
}
