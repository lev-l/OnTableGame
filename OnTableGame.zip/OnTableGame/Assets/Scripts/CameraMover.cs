﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class CameraMover : MonoBehaviour
{
    private Transform _self;
    private Vector3 _target;

    private void SetTarget(KeyCode directionKey, Vector3 direction)
    {
        if (Input.GetKey(directionKey))
        {
            _target = direction;
        }
    }

    private void Start()
    {
        _self = GetComponent<Transform>();
        _target.x = 0;
        _target.y = 0;
        _target.z = _self.position.z;
    }

    private void Update()
    {
        SetTarget(KeyCode.UpArrow, _self.position + Vector3.up);
        SetTarget(KeyCode.DownArrow, _self.position + Vector3.down);
        SetTarget(KeyCode.LeftArrow, _self.position + Vector3.left);
        SetTarget(KeyCode.RightArrow, _self.position + Vector3.right);
        
        if (Mathf.Abs(_target.x - _self.position.x) > 0.05f || Mathf.Abs(_target.y - _self.position.y) > 0.05f)
        {
            Vector3 newPosition = Vector3.Lerp(_self.position, _target, 0.2f);
            _self.position = new Vector3(newPosition.x, newPosition.y, -10);
        }
    }
}
