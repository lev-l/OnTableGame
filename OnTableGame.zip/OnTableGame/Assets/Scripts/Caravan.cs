﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Caravan : MonoBehaviour
{
    public Color[] PlayersColors;
    public State State;
    private SpriteRenderer _renderer;
    private ArmyStats _stats;
    private Resurses _resurses;
    private TurnSystem _turns;
    private Dictionary<States, State> _states;

    void Start()
    {
        _renderer = GetComponent<SpriteRenderer>();
        _resurses = GetComponent<ResuresHandler>().Resurses;

        _states = new Dictionary<States, State>();

        GameObject camera = GameObject.FindGameObjectWithTag("MainCamera");
        _turns = camera.GetComponent<TurnSystem>();

        _stats = new ArmyStats(GetComponent<Transform>(), GetComponent<Transform>().position,
                                _turns.Turn, 0, _turns);
        SetMaster(_turns.Turn);
        _states.Add(States.Default, new DefaultState());
        _states.Add(States.Choosed, new ChoosedState(_stats));
        _states.Add(States.Moving, new MovingState(_stats));
        _states.Add(States.Stoped, new StopedState(_stats));

        State = _states[States.Default];
    }

    public void SetMaster(int master)
    {
        _renderer.color = PlayersColors[master - 1];
        _stats.Master = master;
    }

    public int GetMaster()
    {
        return _stats.Master;
    }

    private void OnMouseDown()
    {
        States newState = State.MousDown();
        State = _states[newState];
    }

    void Update()
    {
        States newState = State.Up();
        State = _states[newState];
        
        if (_resurses.IsAllNull())
        {
            Destroy(gameObject);
        }
    }

    public void AddTurns(int amount)
    {
        _stats.DopTurns += amount;
        State = _states[States.Stoped];
    }

    public void TurnChanged()
    {
        if (_turns.Turn == _stats.Master)
        {
            State.NewTurn();
        }

        _stats.CanMove = 1;
    }
}
