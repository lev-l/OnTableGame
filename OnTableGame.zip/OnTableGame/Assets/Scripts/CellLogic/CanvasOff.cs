﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class CanvasOff : MonoBehaviour
{
    void Update()
    {
        if (Input.GetMouseButton(1))
        {
            gameObject.SetActive(false);
        }
    }
}
