﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class Cell : MonoBehaviour
{
    public GameObject HouseTexture;
    public GameObject WallTexture;
    public GameObject ArmyTexture;
    public GameObject CaravanTexture;
    public Resurses Resurses = new Resurses(0, 0, 0);

    private GameObject _camera;
    private PlayersFirstTownsBools _firstTowns;
    private Transform _self;
    private TurnSystem _turns;

    private bool _hasForest;
    private bool _hasMountian;
    private int _houseCount;
    private int _master = -1;
    private List<Army> _armies = new List<Army>();
    private List<Caravan> _caravans = new List<Caravan>();

    private RemainedArmiesManager _armiesManager;
    private CellCollorManager _colors;
    private CellMenu _menus;
    
    private void Start()
    {
        _houseCount = 0;
        _self = GetComponent<Transform>();
        _menus = GetComponent<CellMenu>();
        _colors = GetComponent<CellCollorManager>();
        _camera = GameObject.FindGameObjectWithTag("MainCamera");
        _firstTowns = _camera.GetComponent<PlayersFirstTownsBools>();
        _turns = _camera.GetComponent<TurnSystem>();
        _armiesManager = _camera.GetComponent<RemainedArmiesManager>();
    }

    private void OnTriggerEnter2D(Collider2D collision)
    {
        if (collision.gameObject.name.Contains("Forest"))
        {
            _hasForest = true;
        }

        if (collision.gameObject.name.Contains("Mountian"))
        {
            _hasMountian = true;
        }

        if (collision.GetComponent<Army>())
        {
            _armies.Add(collision.GetComponent<Army>());
        }

        if (collision.GetComponent<Caravan>())
        {
            _caravans.Add(collision.GetComponent<Caravan>());
        }
    }

    private void OnTriggerExit2D(Collider2D collision)
    {
        if (collision.GetComponent<Army>())
        {
            _armies.Remove(collision.GetComponent<Army>());
        }
        
        if (collision.GetComponent<Caravan>())
        {
            _caravans.Remove(collision.GetComponent<Caravan>());
        }
    }

    public int GetMaster()
    {
        return _master;
    }

    public void CreateHouse()
    {
        if (_master == _turns.Turn || _master == -1)
        {
            if (Resurses.CheckWood(3) || 
                ((_firstTowns.IsFirstTownToPlayer1 && _turns.Turn == 1) ||
                (_firstTowns.IsFirstTownToPlayer2 && _turns.Turn == 2)))
            {
                _master = _turns.Turn;

                _colors.SetNewMasterColor(_master);

                _houseCount++;

                float x = Random.Range(-0.35f, 0.35f);
                float y = Random.Range(-0.35f, 0.35f);
                GameObject newHouse = Instantiate(HouseTexture, _self.position + new Vector3(x, y, 4), Quaternion.identity);
                newHouse.transform.SetParent(_self);

                if (!((_firstTowns.IsFirstTownToPlayer1 && _turns.Turn == 1) ||
                    (_firstTowns.IsFirstTownToPlayer2 && _turns.Turn == 2)))
                {
                    bool minus = Resurses.SetWood(-3);
                    if (!minus)
                    {
                        throw new System.Exception("-value althow 'ifs'");
                    }
                }

                _firstTowns.UnanableFirstTown(_turns.Turn);
            }
        }
    }

    public void BuildWall(Vector2 direction, int rotate)
    {
        if (_houseCount > 0 && _master == _turns.Turn && Resurses.CheckWood(7))
        {
            Resurses.SetWood(-7);
            GameObject wall = Instantiate(WallTexture, new Vector2(_self.position.x + 0.4f * direction.x,
                                                                    _self.position.y + 0.4f * direction.y),
                                                                    Quaternion.identity);
            wall.transform.Rotate(new Vector3(0, 0, rotate));
            wall.GetComponent<Wall>().SetMaster(_turns.Turn);
        }
    }

    public void TraineArmy(ArmyTypes type)
    {
        int[] costResurses = _camera.GetComponent<ArmyTypesCost>().TypesCost[type].GetAll();
        if (_master == _turns.Turn && Resurses.CheckGold(costResurses[2])
                                                    && Resurses.CheckIron(costResurses[1])
                                                    && Resurses.CheckWood(costResurses[0]))
        {
            GameObject newArmy = Instantiate(ArmyTexture, _self);
            newArmy.GetComponent<Army>().SetMaster(_master);
            newArmy.GetComponent<Army>().GetComponent<ArmyType>().SetNewType(type);

            Resurses.SetGold(-costResurses[2]);
            Resurses.SetIron(-costResurses[1]);
            Resurses.SetWood(-costResurses[0]);
        }
    }

    public void CreateCaravan()
    {
        if (_master == _turns.Turn && Resurses.CheckGold(1)
                                    && Resurses.CheckWood(1))
        {
            Instantiate(CaravanTexture, _self).GetComponent<ResuresHandler>().Resurses.SetWood(1);

            Resurses.SetGold(-1);
            Resurses.SetWood(-1);
        }
    }

    public void TurnChanged()
    {
        Army[] losers = _armiesManager.CheckBatleStart(_armies, this);
        if (losers != null)
        {
            foreach (Army loser in losers)
            {
                _armies.Remove(loser);
            }
        }

        List<Army> first = new List<Army>();
        List<Army> second = new List<Army>();
        foreach (Army army in _armies)
        {

            if (army.GetMaster() == 1)
            {
                first.Add(army);
            }
            else
            {
                second.Add(army);
            }
        }

        if (_master == 1 && second.Count != 0 && first.Count == 0)
        {
            _master = 2;
            _colors.SetNewMasterColor(_master);
        }
        else if (_master == 2 && first.Count != 0 && second.Count == 0)
        {
            _master = 1;
            _colors.SetNewMasterColor(_master);
        }

        _armiesManager.CheckRob(_armies, _caravans, this);

        if (_master == _turns.Turn)
        {
            if (_hasForest)
            {
                Resurses.SetWood(_houseCount);
            }
            if (_hasMountian)
            {
                Resurses.SetIron(_houseCount);
            }
            
            Resurses.SetGold(_houseCount / 2);
        }
    }
}
