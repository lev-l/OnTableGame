﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class CellCollorManager : MonoBehaviour
{
    private SpriteRenderer _renderer;
    private Color _standartColor;
    private Color _enterColor;
    private Color _player1Color;
    private Color _player2Color;

    void Start()
    {
        _renderer = GetComponent<SpriteRenderer>();
        _standartColor = _renderer.color;
        _enterColor = new Color(0, 255, 0);
        _player1Color = new Color(0, 10, 5);
        _player2Color = new Color(5, 10, 0);
    }

    private void OnMouseEnter()
    {
        _renderer.color = _enterColor;
    }

    private void OnMouseExit()
    {
        _renderer.color = _standartColor;
    }

    public void SetNewMasterColor(int master)
    {
        switch (master)
        {
            case 1:
                _standartColor = _player1Color;
                break;
            case 2:
                _standartColor = _player2Color;
                break;
        }

        _renderer.color = _standartColor;
    }
}
