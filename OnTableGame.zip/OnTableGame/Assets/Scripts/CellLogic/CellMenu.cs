﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

[System.Serializable]
public class CellMenu : MonoBehaviour
{
    public GameObject Tools;
    public GameObject ArmiesTypesButtons;
    public GameObject ResursesView;

    private GameObject _camera;
    private Transform _self;
    private Text GoldText;
    private Text WoodText;
    private Text IronText;

    void Awake()
    {
        _self = GetComponent<Transform>();
        _camera = GameObject.FindGameObjectWithTag("MainCamera");

        Tools = Instantiate(Tools, _self.position + new Vector3(1, 0, 5), Quaternion.identity);
        Tools.GetComponent<Canvas>().worldCamera = _camera.GetComponent<Camera>();

        ArmiesTypesButtons = Instantiate(ArmiesTypesButtons, _self);
        ArmiesTypesButtons.GetComponent<Canvas>().worldCamera = _camera.GetComponent<Camera>();

        Button[] buttons = Tools.GetComponentsInChildren<Button>();
        buttons[0].onClick.AddListener(delegate { GetComponent<Cell>().CreateHouse(); });
        buttons[1].onClick.AddListener(delegate { ArmiesTypesButtons.SetActive(true); });
        buttons[3].onClick.AddListener(delegate { GetComponent<Cell>().CreateCaravan(); });

        buttons = ArmiesTypesButtons.GetComponentsInChildren<Button>();
        buttons[0].onClick.AddListener(delegate { GetComponent<Cell>().TraineArmy(ArmyTypes.Arrow); });
        buttons[1].onClick.AddListener(delegate { GetComponent<Cell>().TraineArmy(ArmyTypes.Spear); });
        buttons[2].onClick.AddListener(delegate { GetComponent<Cell>().TraineArmy(ArmyTypes.Sword); });
        buttons[3].onClick.AddListener(delegate { GetComponent<Cell>().TraineArmy(ArmyTypes.Horse); });

        Button[] wallButtons = Tools.GetComponentInChildren<Panel>().GetComponentsInChildren<Button>();
        wallButtons[0].onClick.AddListener(delegate { GetComponent<Cell>().BuildWall(new Vector2(0, 1), 90); });
        wallButtons[1].onClick.AddListener(delegate { GetComponent<Cell>().BuildWall(new Vector2(0, -1), 90); });
        wallButtons[2].onClick.AddListener(delegate { GetComponent<Cell>().BuildWall(new Vector2(-1, 0), 0); });
        wallButtons[3].onClick.AddListener(delegate { GetComponent<Cell>().BuildWall(new Vector2(1, 0), 0); });

        ResursesView = Instantiate(ResursesView, _self.position + new Vector3(-1, 1, 5), Quaternion.identity);

        Text[] texts = ResursesView.GetComponentInChildren<Transform>().GetComponentsInChildren<Text>();

        foreach (Text text in texts)
        {
            switch (text.text)
            {
                case "Gold:":
                    GoldText = text;
                    break;
                case "Wood:":
                    WoodText = text;
                    break;
                case "Iron:":
                    IronText = text;
                    break;
            }
        }
    }

    private void OnMouseDown()
    {
        Tools.SetActive(true);
        ResursesView.SetActive(true);
    }

    private void Update()
    {
        int[] items = GetComponent<Cell>().Resurses.GetAll();

        GoldText.text = "Gold: " + items[2].ToString();
        WoodText.text = "Wood: " + items[0].ToString();
        IronText.text = "Iron: " + items[1].ToString();
    }
}
