﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class RemainedArmiesManager : MonoBehaviour
{
    public Army[] CheckBatleStart(List<Army> armies, Cell cell)
    {
        List<Army> armiesOf1 = new List<Army>();
        List<Army> armiesOf2 = new List<Army>();

        foreach (Army army in armies)
        {
            if (army.GetMaster() == 1)
            {
                armiesOf1.Add(army);
            }
            else if (army.GetMaster() == 2)
            {
                armiesOf2.Add(army);
            }
            else
            {
                throw new System.Exception("Army has not master");
            }
        }
        
        if (armiesOf1.Count != 0 && armiesOf2.Count != 0)
        {
            Army[] loser = GetComponent<Batle>().SimulateButle(armiesOf1.ToArray(), armiesOf2.ToArray(), cell);
            return loser;
        }
        return null;
    }

    public Caravan[] CheckRob(List<Army> armies, List<Caravan> caravans, Cell cell)
    {
        List<Army> armiesOf1 = new List<Army>();
        List<Army> armiesOf2 = new List<Army>();
        List<Caravan> caravans1 = new List<Caravan>();
        List<Caravan> caravans2 = new List<Caravan>();

        foreach (Army army in armies)
        {
            if (army.GetMaster() == 1)
            {
                armiesOf1.Add(army);
            }
            else if (army.GetMaster() == 2)
            {
                armiesOf2.Add(army);
            }
            else
            {
                throw new System.Exception("Army has not master");
            }
        }
        foreach (Caravan caravan in caravans)
        {
            if (caravan.GetMaster() == 1)
            {
                caravans1.Add(caravan);
            }
            if (caravan.GetMaster() == 2)
            {
                caravans2.Add(caravan);
            }
        }

        if (armiesOf1.Count > 0 && caravans2.Count > 0)
        {
            foreach(Caravan caravan in caravans2)
            {
                caravan.SetMaster(1);
            }
        }
        if (armiesOf2.Count > 0 && caravans1.Count > 0)
        {
            foreach (Caravan caravan in caravans1)
            {
                caravan.SetMaster(2);
            }
        }
        return caravans.ToArray();
    }
}
