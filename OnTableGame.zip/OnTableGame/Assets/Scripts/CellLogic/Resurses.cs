﻿public class Resurses
{
    private int _wood;
    private int _iron;
    private int _gold;

    public Resurses(int gold, int wood, int iron)
    {
        _wood = wood;
        _iron = iron;
        _gold = gold;
    }

    public bool IsAllNull()
    {
        return _wood == 0 && _iron == 0 && _gold == 0;
    }

    public bool SetWood(int value)
    {
        if (_wood >= value || value > 0)
        {
            _wood += value;
            return true;
        }
        return false;
    }
    public bool CheckWood(int expectValue)
    {
        return _wood >= expectValue;
    }

    public bool SetIron(int value)
    {
        if (_iron >= value || value > 0)
        {
            _iron += value;
            return true;
        }
        return false;
    }
    public bool CheckIron(int expectValue)
    {
        return _iron >= expectValue;
    }

    public bool SetGold(int value)
    {
        if (_gold >= value || value > 0)
        {
            _gold += value;
            return true;
        }
        return false;
    }
    public bool CheckGold(int expectValue)
    {
        return _gold >= expectValue;
    }

    public int[] GetAll()
    {
        int[] returns = { _wood, _iron, _gold };
        return returns;
    }
}