﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PlayersFirstTownsBools : MonoBehaviour
{
    public bool IsFirstTownToPlayer1 = true;
    public bool IsFirstTownToPlayer2 = true;

    public void UnanableFirstTown(int playerNumber)
    {
        switch (playerNumber)
        {
            case 1:
                IsFirstTownToPlayer1 = false;
                break;
            case 2:
                IsFirstTownToPlayer2 = false;
                break;
            default:
                break;
        }
    }
}
