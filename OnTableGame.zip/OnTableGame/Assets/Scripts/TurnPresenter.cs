﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class TurnPresenter : MonoBehaviour
{
    public TurnSystem TurnNow;
    public Text TurnPresent;

    public void PresentTurn()
    {
        TurnPresent.text = TurnNow.Turn.ToString();
    }
}
