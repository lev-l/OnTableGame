﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class TurnSystem : MonoBehaviour
{
    public GameObject Reciver;
    public int Turn = 1;

    public void NextTurn()
    {
        if (Turn < 2)
        {
            Turn++;
        }
        else
        {
            Turn = 1;
        }

        Cell[] lands = Reciver.GetComponentsInChildren<Cell>();
        foreach (Cell land in lands)
        {
            land.TurnChanged();
        }

        Army[] armies = Reciver.GetComponentsInChildren<Army>();
        foreach (Army army in armies)
        {
            army.TurnChanged();
        }

        Caravan[] caravans = Reciver.GetComponentsInChildren<Caravan>();
        foreach (Caravan caravan in caravans)
        {
            caravan.TurnChanged();
        }
    }
}
