﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Wall : MonoBehaviour
{
    private int _master = 0;

    public void SetMaster(int value)
    {
        _master = value;
    }

    private void OnTriggerEnter2D(Collider2D collision)
    {
        if (collision.gameObject.name.Contains("Army"))
        {
            if (collision.GetComponent<Army>().GetMaster() != _master)
            {
                if (collision.GetComponent<ArmyType>().Type == ArmyTypes.Arrow)
                {
                    if (Random.Range(1, 7) > 4)
                    {
                        Destroy(gameObject);
                    }
                    else
                    {
                        collision.gameObject.GetComponent<Army>().Stats.SetOldTarget();
                    }
                }
                else
                {
                    collision.gameObject.GetComponent<Army>().Stats.SetOldTarget();
                }
            }
        }
    }
}
